"""Reproduce the saved paired seed/query bootstrap samples exactly (CPU only)."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    args = parser.parse_args()
    report = json.loads((args.root / "results.json").read_text())
    saved = np.load(args.root / "paired_bootstrap_samples.npz")
    arrays = {}
    for method in report["summary"]:
        rows = []
        for run in report["runs"]:
            if run["method"] != method:
                continue
            data = json.loads((args.root / f"{method}_seed{run['seed']}" / "test_per_query.json").read_text())
            assert [row["query_id"] for row in data] == sorted(row["query_id"] for row in data)
            rows.append([row["ndcg_at_10"] for row in data])
        arrays[method] = np.array(rows)
    comparisons = {}
    for method, reference in (("lora", "frozen"), ("dora", "lora"), ("nora", "lora"),
                              ("dora_nora", "nora"), ("dora_nora", "lora"), ("dora", "frozen")):
        delta = arrays[method] - arrays[reference]
        rng = np.random.default_rng(123456)
        seed_index = rng.integers(0, 3, size=(10000, 3))
        query_index = rng.integers(0, 300, size=(10000, 300))
        samples = delta[seed_index[:, :, None], query_index[:, None, :]].mean(axis=(1, 2))
        name = f"{method}_minus_{reference}"
        np.testing.assert_array_equal(samples, saved[name])
        comparisons[name] = {"mean_delta": float(delta.mean()), "percentile_95_ci": np.quantile(samples, [0.025, 0.975]).tolist()}
    declared = json.loads((args.root / "paired_bootstrap.json").read_text())
    assert comparisons == declared["comparisons"]
    print(json.dumps({"all_original_samples_reproduced_exactly": True,
                      "comparisons": len(comparisons), "replicates_each": 10000,
                      "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                      "numpy": np.__version__}, indent=2))


if __name__ == "__main__":
    main()
