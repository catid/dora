"""CPU-only independent checks and paired bootstrap for recorded vision runs."""
import hashlib
import json
from pathlib import Path
import statistics

import numpy as np

ROOT = Path(__file__).resolve().parent
METHODS = ['baseline', 'lora', 'dora', 'nora', 'dora_nora']
SEEDS = [42, 43, 44]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


runs = json.loads((ROOT / 'results.json').read_text())
assert len(runs) == 15
assert {(r['method'], r['seed']) for r in runs} == {(m, s) for m in METHODS for s in SEEDS}
manifest = json.loads((ROOT / 'split_manifest.json').read_text())
expected_labels = np.asarray([row['label'] for row in manifest['test']])
assert len(expected_labels) == 6149
splits = [{row['image'] for row in manifest[split]} for split in ('train', 'val', 'test')]
assert [len(x) for x in splits] == [1020, 1020, 6149]
assert all(not splits[i] & splits[j] for i in range(3) for j in range(i+1, 3))
selected = json.loads((ROOT / 'selected_learning_rates.json').read_text())
source = json.loads((ROOT / 'source' / 'manifest.json').read_text())
for filename, info in source.items():
    if isinstance(info, dict):
        assert sha(ROOT / 'source' / filename) == info['sha256']
correctness = {method: [] for method in METHODS}
for seed in SEEDS:
    heads = set()
    for method in METHODS:
        run = next(r for r in runs if r['seed'] == seed and r['method'] == method)
        directory = ROOT / f'seed_{seed}' / method
        predictions = json.loads((directory / 'test_predictions.json').read_text())
        labels, predicted = np.asarray(predictions['labels']), np.asarray(predictions['predictions'])
        assert np.array_equal(labels, expected_labels)
        assert predicted.shape == labels.shape and np.all((predicted >= 0) & (predicted < 102))
        correct = labels == predicted
        assert int(correct.sum()) == run['test']['correct']
        assert len(correct) == run['test']['count'] == 6149
        assert abs(correct.mean() - run['test']['accuracy']) < 1e-14
        macro = np.mean([correct[labels == label].mean() for label in range(102)])
        assert abs(macro - run['test']['macro_class_accuracy']) < 1e-6
        correctness[method].append(correct.astype(np.float64))
        assert run['frozen_base_unchanged']
        assert run['initial_backbone_sha256'] == run['frozen_state_before_sha256'] == run['frozen_state_after_sha256']
        assert run['source_state_sha256'] == run['loaded_source_state_sha256']
        assert run['initial_trainable_sha256'] != run['final_trainable_sha256']
        assert run['provenance']['script_sha256'] == source['experiments/vision.py']['sha256']
        assert run['provenance']['adapters_sha256'] == source['experiments/adapters.py']['sha256']
        assert run['best_adapter_checkpoint_sha256'] == sha(directory / 'best_adapter_and_head.pt')
        assert run['epochs'] == 30 and run['rank'] == 8 and run['head_learning_rate'] == 0.001
        assert run['adapter_learning_rate'] == selected[method]
        assert run['evaluate_test'] is True
        heads.add(run['initial_head_sha256'])
        history = [json.loads(line) for line in (directory / 'epochs.jsonl').read_text().splitlines()]
        assert len(history) == 30
        assert all(x['train']['count'] == 1020 and x['validation']['count'] == 1020 for x in history)
        chosen = max(history, key=lambda x: (x['validation']['accuracy'], -x['validation']['cross_entropy']))
        assert chosen['epoch'] == run['best_epoch']
        assert chosen['validation'] == run['best_validation']
        assert all(x['up_factor_l2_norm'] > 0 for x in run['row_norm_diagnostics']['layers'])
    assert len(heads) == 1, 'Head initialization differed across methods within a seed'
assert len({r['checkpoint_sha256'] for r in runs}) == 1
assert len({r['source_state_sha256'] for r in runs}) == 1
assert len({r['initial_backbone_sha256'] for r in runs}) == 1
pilots = json.loads((ROOT / 'pilot_results.json').read_text())
assert len(pilots) == 8
for method in METHODS[1:]:
    trials = [run for run in pilots if run['method'] == method]
    assert {run['adapter_learning_rate'] for run in trials} == {0.0001, 0.001}
    assert all(run['epochs'] == 5 and run['seed'] == 42 and run['test'] is None and not run['evaluate_test'] for run in trials)
    winner = max(trials, key=lambda run: (run['best_validation']['accuracy'], -run['best_validation']['cross_entropy']))
    assert selected[method] == winner['adapter_learning_rate']
summary = {'dataset': 'Flowers102 official split', 'seeds': SEEDS, 'methods': {},
           'independent_integrity_checks_passed': True, 'final_runs': 15, 'validation_only_pilots': 8,
           'selected_adapter_learning_rates': selected,
           'checks': ['prediction counts and exact top-1', 'macro class accuracy', 'test label order',
                      'disjoint official splits', 'same pretrained source and backbone for all runs',
                      'same seeded classifier initialization across methods', 'base frozen before and after',
                      'nonzero learned adapters and changed trainable state', 'validation-only checkpoint selection',
                      'equal validation-only LR search budgets', 'snapshot and checkpoint SHA256 matches']}
for method in METHODS:
    rows = [r for r in runs if r['method'] == method]
    output = {'trainable_parameters': rows[0]['trainable_parameters'], 'per_seed': []}
    for run in rows:
        output['per_seed'].append({'seed': run['seed'], **run['test'], 'best_epoch': run['best_epoch']})
    for label, values in {
        'test_accuracy_percent': [100*r['test']['accuracy'] for r in rows],
        'macro_class_accuracy_percent': [100*r['test']['macro_class_accuracy'] for r in rows],
        'test_cross_entropy': [r['test']['cross_entropy'] for r in rows],
        'training_wall_seconds': [r['training_wall_seconds'] for r in rows],
        'peak_cuda_allocated_gib': [r['peak_cuda_allocated_bytes']/2**30 for r in rows],
    }.items():
        output[label] = {'mean': statistics.mean(values), 'sample_std': statistics.stdev(values)}
    summary['methods'][method] = output
# Resample seeds and test images together for paired method comparisons. The
# resulting exploratory interval includes observed initialization variation,
# but three seeds cannot characterize the full distribution of training runs.
rng = np.random.default_rng(20261008)
comparisons = [m for m in METHODS if m != 'lora']
differences = np.stack([np.stack(correctness[m]) - np.stack(correctness['lora']) for m in comparisons])
bootstraps = np.empty((10000, len(comparisons)))
for repetition in range(len(bootstraps)):
    seed_indices = rng.integers(0, 3, size=3)
    image_indices = rng.integers(0, 6149, size=6149)
    bootstraps[repetition] = differences[:, seed_indices].mean(axis=1)[:, image_indices].mean(axis=1)*100
summary['paired_bootstrap_vs_lora'] = {
    'replicates': 10000, 'rng_seed': 20261008,
    'method': 'paired seed and image resampling with replacement; percentile 95% intervals',
    'caveat': 'Exploratory; only three training seeds and one held-out test set. Not a claim of universal superiority.',
    'comparisons': {method: {'mean_accuracy_difference_percentage_points': differences[index].mean()*100,
                             'percentile_95_interval': np.quantile(bootstraps[:, index], [0.025, 0.975]).tolist()}
                    for index, method in enumerate(comparisons)}}
(ROOT / 'summary_audited.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
